
public class Hw3 {

	public static void main(String[] args) {
		
		String name = "Thomas Feliks Nommsalu";
		
		System.out.print(name.charAt(0));
		
		System.out.print(name.charAt(7));
		
		System.out.print(name.charAt(14));
	}

}
