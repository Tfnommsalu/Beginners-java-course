
public class Hw1 {
	public static void main(String[] args) {

	String text = "Life is beautiful" ;
	
	System.out.println(text.substring(0, 4));
	
	
	
	
	
}
	}