
public class Hw2 {

	public static void main(String[] args) {
	
		System.out.println("Life is beautiful, and so are you.");
		
		System.out.println("I have rephrased that line to read:");
		
			String name = "Life is beautiful, and so are you.";
	
		System.out.println(name.replaceFirst("beautiful", "tough"));
	
	}

}
