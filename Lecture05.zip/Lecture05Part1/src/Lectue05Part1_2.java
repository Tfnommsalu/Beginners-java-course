import java.util.Random;
import java.util.Scanner;

public class Lectue05Part1_2 {

	public static void main(String[] args) {
		System.out.println("Lecture 05 21 sticks");
		
		//keep track of the number of sticks
		int numberOfSticks = 21; //initial number
		
		// get the user input
		Scanner input = new Scanner(System.in);// who goes first
		Scanner take = new Scanner(System.in);// 1 or 2 sticks
		int numberToTake = 0;
		
		System.out.println("Would you like to go first? (y/n)");
		String goFirst = input.nextLine(); // y or n
		
		while (numberOfSticks > 0) { //if there any sticks left
		
			if (goFirst.equals("y") | goFirst.equals("Y") ) {
				System.out.println("You go first");
				System.out.println("There are " + numberOfSticks + " sticks");
				System.out.println("How many sticks to take (1 or 2)?");
				numberToTake = take.nextInt();
				if (numberToTake > 2) {
					numberToTake = 2;
				} else if (numberToTake < 1) {
					numberToTake = 1;
				}
				
				numberOfSticks = numberOfSticks - numberToTake;
				
				if (numberOfSticks <= 0) {
					System.out.println("You lose");	
				
				} else { //computer's turn
					
					Random rand = new Random();
					numberToTake = rand.nextInt(3);// 1 or 2
					System.out.println("Computer takes " + numberToTake + " sticks");			
					numberOfSticks = numberOfSticks - numberToTake;
					if (numberOfSticks <= 0) {
						System.out.println("You win!"); // computer lose	
					
					}	
					
					
				}
				
				
				
				
			} else {
				System.out.println("Computer goes first");
				
				Random rand = new Random();
				numberToTake = rand.nextInt(2) + 1;// 1 or 2, 0 excluded
				System.out.println("Computer takes " + numberToTake + " sticks");			
				numberOfSticks = numberOfSticks - numberToTake;
				if (numberOfSticks <= 0) {
					System.out.println("You win!"); // computer lose	
				
				} else {
					System.out.println("There are " + numberOfSticks + " sticks");
					System.out.println("How many sticks to take (1 or 2)?");
					numberToTake = take.nextInt();
					if (numberToTake > 2) {
						numberToTake = 2;
					} else if (numberToTake < 1) {
						numberToTake = 1;
					}
					
					numberOfSticks = numberOfSticks - numberToTake;
					
					if (numberOfSticks <= 0) {
						System.out.println("You lose");	
					
					} 
				}
				
			}
		} //end of while
		

	}

}
