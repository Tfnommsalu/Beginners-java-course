import java.util.Random;
import java.util.Scanner;

public class Lecture05Part1Test {

	public static void main(String[] args) {
		System.out.println("Lecture 05 Guessing Game");
		//Create a random number to guess between 1 and 1000
		Random rand = new Random();
		
		int numberToGuess = rand.nextInt(1000);
		//System.out.println("numberToGuess " + numberToGuess);
	
		//Keep track of number of guesses
		int numberOfTries = 0;
	
		//Let user input a number
		Scanner input = new Scanner(System.in);
			
		//Keep playing until we guess the correct number
        boolean win = false; // false by default
		
		while (win == false) {
		
			///------------------------------------------
			//Ask to guess a number
			System.out.println("Guess a number between 1 and 1000:");
			
			int guess = input.nextInt();
			//System.out.println("guess " + guess);
			numberOfTries ++; //numberOfTries = numberOfTries + 1;
	
			//Tell whether we're guessing too high or too low
			if (guess == numberToGuess) {
				win = true; // we won!
				System.out.println("Congrats!");
			} else if (guess < numberToGuess) {
				System.out.println("Your guess is too low");
			} else { /// guess > numberToGuess
				System.out.println("Your guess is too high");
			}
		
		}//end of while
		//------------------------------------------
		
		System.out.println("The number was " + numberToGuess);
		System.out.println("It took you " + numberOfTries + " tries");
		
	}

}
