
public class Lecture05Test {

	public static void main(String[] args) {
		System.out.println("Lecture 05 Part 2");
		char [] symbolsArray = {'H', 'e', 'l', 'l', 'o'};
		System.out.println(symbolsArray[0]);
		System.out.println(symbolsArray[1]);
		System.out.println(symbolsArray[symbolsArray.length- 1]);
		
		String text = new String(symbolsArray);
		System.out.println(text);
		System.out.println(text.length()); // amount of characters
		
		String name = "John Johnson";
		//String name = "Johnathan Johnson";
		System.out.println(name.length()); // amount of characters
		System.out.println(name.indexOf(" "));//4
		int index = name.indexOf(" ");
		// find the last and first name 
		System.out.println(  name.substring( index + 1 ) );//Johnson
		System.out.println(  name.substring(0, index ) );//John
		
		System.out.println(name.indexOf("o"));//1
		
		//String location = "Tallinn, Estonia";
		String location = "Paris, France";
		//find town
		index = location.indexOf(",");
		String town = location.substring(0, index);
		System.out.println("Town : " + town);
		
		String coutry = location.substring(index +2);
		System.out.println("Country : " + coutry);
		
		
	}

}
