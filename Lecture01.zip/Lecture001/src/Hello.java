
public class Hello {

	public static void main(String[] args) {
		
	
		System.out.println("Hello!!!!");
		System.out.println("Hello!!!!");
		System.out.println("Hello!");
		
		int  number; //define variable
		
		number = 5; //initialize, assign the value 
		System.out.println(number);
		
		System.out.println(7);
		
		number = 0; // reassign the value
		System.out.println(number);
		
	//	number = 9.5;
		
		double decimalNumber = 15.5; 
		System.out.println(decimalNumber);
		
		number = 22;
		
		System.out.println("He is " + number + " years old");
		
		String name = "Inna";
		System.out.println(name);
		System.out.println("Hello " + name);
		System.out.println("Hello " + name + "!");
		
				
		
		
		
		
		
		
		
	}

}
