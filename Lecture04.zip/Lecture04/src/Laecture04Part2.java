import java.util.Scanner;

public class Laecture04Part2 {

	public static void main(String[] args) {
		// FOR LOOP: print odd numbers in a range 1-60
		for (int i = 1; i <= 60; i ++) {
			if (i%2 == 1) {
				System.out.println(i);	
			}
		}
		
		System.out.println();	
		for (int i = 1; i <= 60; i +=2) { // 1+2 , 3+2 ....
				System.out.println(i);	
		}
		
		System.out.println();
		// FOR LOOP: print odd numbers in an array
		int [] numbers = {3, 7, -2, 4, -12, 1, 90, 50, -8};
		
		for (int i = 0; i < numbers.length; i ++) {
			
			if (numbers[i]%2 == 1) {
				System.out.println(numbers[i]);	
			}
		}
		
		System.out.println();
		int counter = 0;
		// FOR LOOP: find the amount of odd numbers in an array
		for (int i = 0; i < numbers.length; i ++) {
			
			if (numbers[i]%2 == 1) {
				//System.out.println(numbers[i]);
				counter ++ ;
			}
		}
		System.out.println("There are " + counter + " odd numbers here");
		
		System.out.println(); //empty string
		
		// FOR LOOP: print all negative values 
		for (int i = 0; i < numbers.length; i ++) {
			
			if (numbers[i]   < 0 ) { //check negativeness
				System.out.println(numbers[i]);	
			}
		}
		
		counter = 0;
		// FOR LOOP: find the amount of positive numbers in an array
		for (int i = 0; i < numbers.length; i ++) {
			
			if (numbers[i]   >  0 ) { 
				System.out.println(numbers[i]);
				counter ++;
			}
		}
		System.out.println("There are " + counter + " positive numbers here");
		
		// write a program to ask user for password 
		// user creates a password and needs to confirm it
		Scanner sc = new Scanner (System.in);
		
		/*System.out.println("Please enter a password: ");
		String password= sc.nextLine();
		
		System.out.println(password);
		
		System.out.println("Confirm password: ");
		String reentered = sc.nextLine();
		if (! reentered.equals(password)) {
			System.out.println("Passwords are different");	
		}*/
		
		String password;
		String reentered;
		do {
			System.out.println("Please enter a password: ");
			password = sc.nextLine();
			System.out.println("Confirm password: ");
			reentered = sc.nextLine();
				
			
		//} while (!reentered.equals(password));
		} while (!reentered.equals(password));
		
		
		System.out.println("Password confirmed.");

		// write a program to ask user for their name and age   
		// make it possible to leave the program after each question
		
		
	    String input;
	    
		System.out.println("Hello! What is your name? ");
		input = sc.nextLine();
		System.out.println("Hello " + input + "!");
		
		System.out.println("Do you want to continue? (y/n)");
		input = sc.nextLine();
		if (input.equals("n")) {
			System.out.println("Thank you! Bye!");		
		} else {
			
			int number = 5;
			int guess = -100000;
			while (guess != number) {
			
				System.out.println("Guess a number");
				guess = sc.nextInt();
					
			}
			
			System.out.println("Your guess was correct! Congrats!");	
		
		}
		
	
		
			
	}

}
