
public class Lecture04Part1 {

	public static void main(String[] args) {
		System.out.println("Lecture 04");
		
		System.out.println("WHILE loop");
		int counter = 0; //int counter = 5;
		
		while (counter < 5) {
			System.out.println(" * * * " + counter);
			counter ++;//increase the value on each step
		}//end of while
		
		System.out.println();
		System.out.println("DO WHILE loop");
		counter = 0; //counter = 5;
		
		do {
			System.out.println(" * * * " + counter);
			counter ++;
		} while (counter <5);
		
		System.out.println();//empty string
		System.out.println("FOR loop");
		for (int count = 0; count <= 4; count ++) {
			
			System.out.println(" * * * " + count);
		}
		
		// print you name 25 times
		for (int i = 1; i <= 25; i ++) {
			System.out.println(i + " John");
		}//end of for
		
		int [] temperatures = {4, 5, 0, -2, 4, 1, 3};
		System.out.println(temperatures [0]);
		System.out.println(temperatures [1]);
		System.out.println(temperatures [2]);
		System.out.println(temperatures [6]);//last element 7-1 = 6
		System.out.println(temperatures [temperatures.length - 1]);//last element 7-1 = 6
		System.out.println();//empty string
		
		for (int i = 0; i < temperatures.length; i ++) {
			System.out.println(temperatures [i]);	
		}//end of for
		
		// find the avg temperature of the week
		
		//(temperatures [0] + temperatures [1] + ...+temperatures [6])/ 7
		
		int sum = 0;
		int  avg = 0;
		//{4, 5, 0, -2, 4, 1, 3};
		System.out.println();//empty string
		for (int i = 0; i < temperatures.length; i ++) {
			//System.out.println(temperatures [i]);
			sum = sum + temperatures [i]; 
			//System.out.println("Current sum  " + sum);
		}//end of for
		
		avg = sum / temperatures.length;
		System.out.println("Avg temperature last week " + avg + " degrees");
		
		System.out.println();//empty string
		//for (int i = 0; i < temperatures.length; i ++) {
		for (int t : temperatures) {
			System.out.println(t);
		}
		
		
		
		
		
	}

}
