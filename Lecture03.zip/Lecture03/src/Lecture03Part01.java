import java.util.Scanner;

public class Lecture03Part01 {

	public static void main(String[] args) {
		//sys CTRL+SPACE enter
		System.out.println("Lecture 03");
		
		//double balance = 100.00;
		//double balance = 0;
		double balance = -10;
	    //If the variable balance is equal to 0... 
		if ( balance == 0) {
			System.out.println("Balance is equal to 0, add funds soon.");
			
		}//If the variable balance is set to a positive number...
		else if (balance > 0) {
			System.out.println("Balance : " + balance);
		}//If the variable balance is set to a negative number...
		else {
			System.out.println("Balance is below 0, "
							+ "add funds now or you "  
							+ "will be charged a penalty" );
		}
	//---------------------------------------------------	
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Input purchase amount ");
		double amount = sc.nextDouble();
		double amountToPay = amount; 
		if (amount < 100) {
			System.out.println("No discount");	
		} else {
			//110 --> 100 + (10 -10%) --> 109
			System.out.println("10% off on everything above $100");
            amountToPay = 100 + (amount - 100)*0.9; 		
		}
		System.out.println("Final amount to pay : " + amountToPay);
		/**********************************/
		amountToPay = amount; 
		if (amount < 100) {
			System.out.println("No discount");	
		//} else if (amount >= 100 & amount < 1000 ){
		} else if (amount < 1000 ){
			//110 --> 100 + (10 -10%) --> 109
			System.out.println("10% off on everything above $100");
            amountToPay = 100 + (amount - 100)*0.9; 		
		} else if (amount < 2000 ){
			System.out.println("15% off on everything above $1000");
            amountToPay = 100 + (amount - 100)*0.85; 		
		} else {
			System.out.println("20% off on everything above $2000");
            amountToPay = 100 + (amount - 100)*0.8;
		}
		
		System.out.println("Final amount to pay : " + amountToPay);
		
		
		
		
		
		
		

	}

}
