import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class LectureTest {

	public static void main(String[] args) throws IOException {
		
		File myFile = new File("C:\\Users\\Student\\Desktop\\test.txt");
		
		if (myFile.createNewFile()) {
			System.out.println(myFile.getPath() +" created");
		} else {
			System.out.println(myFile.getPath() +" exists");
		}
		//write 5 salary values into the file
		
		PrintWriter writer = new PrintWriter(myFile);
		writer.println(1250.50);
		writer.println(2250.00);
		writer.println(1450.90);
		writer.println(1260.80);
		writer.println(1259.00);
		writer.println(3259.00);
	//	writer.println("Hello");
		
		writer.close();
		
		//read salary values from file		
		//calculate average value
		
		FileReader fileReader = new FileReader(myFile);
		
		BufferedReader reader = new BufferedReader(fileReader);
		
		String str;
		double salary;
		double sum = 0;
		double avg;
		int counter = 0;
		
		do {
		
			str = reader.readLine();
			
			if (str != null ) { 
			
			//	System.out.println(str);
				//parse double value out of string
				salary = Double.parseDouble(str);
				//find sum
				sum  = sum  + salary;
			//	System.out.println("Current sum " + sum);
				counter ++;
			}
			
		} while (str != null);// as far as line is not empty
		
		avg = sum /counter ;
		System.out.println("Avg salary is " + avg);
		
		reader.close();
		fileReader.close();
		
		
		
		
		
		
		
		

	}

}
