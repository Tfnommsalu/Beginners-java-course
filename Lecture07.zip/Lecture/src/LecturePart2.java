import java.util.Scanner;

public class LecturePart2 {

	public static void main(String[] args) {
		System.out.println("Lecture 07");
		
		int result = 0;
		int a, b;
		a = 5;
		b = 7;
		
		result = a + b;
		System.out.println(result);
		result = add(a, b);
		System.out.println(result);
		System.out.println( add(a, b));
		System.out.println( add(44, 7));
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please input a: ");
		a = sc.nextInt();
		
		System.out.println( "a is a " + (isPositive(a)?"positive value":"negative value"));
		
		System.out.println("Please input b: ");
		b = sc.nextInt();
		System.out.println( "b is a " + (isPositive(b)?"positive value":"negative value"));
		
		System.out.println("a + b = " + add(a, b));
		
		String [] names = {"Anna", "Ali", "Julia"};
		printArray(names);
		
		
		String [] countries = {"Estonia", "Latvia"};
		printArray(countries);
		
		String [] towns = new String[5];
		towns[0] = "Tallinn";
		towns[3] = "Tartu";
		printArray(towns);
		
			
	}//end of main
	
	//write a method to print an array of Strings
	public static void printArray( String [] array) {
		System.out.println("Printing array :");
		for (String str : array) {
			System.out.println(str);
		}
		System.out.println();
	}
	
	
	//write a method to check if the value is positive
	public static boolean isPositive(int value) {
		if (value > 0) {
			return true;
		}
		return false;
	}	
	public static int add (int number1, int number2) {
		
		int result = number1 + number2;
		
		return result;
	}
	
	

}//end of class
