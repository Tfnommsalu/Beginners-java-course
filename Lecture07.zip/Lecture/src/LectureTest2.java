import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class LectureTest2 {

	public static void main(String[] args) throws IOException {
File myFile = new File("C:\\Users\\Student\\Desktop\\Book1.csv");
		
		//read salary values from CSV file		
		//calculate average value
		
		FileReader fileReader = new FileReader(myFile);
		
		BufferedReader reader = new BufferedReader(fileReader);
		
		String str;
		double salary;
		double sum = 0;
		double avg;
		int counter = 0;
		
		do {
		
			str = reader.readLine();
			
			if (str != null ) { 
			
				System.out.println(str);
				//John,1234,Tallinn
				int beginIndex = str.indexOf(",") + 1;
				int endIndex = str.lastIndexOf(",");
				//find a substring
				str = str.substring(beginIndex, endIndex);
				System.out.println(str);
				//parse double value out of string
				salary = Double.parseDouble(str);
				//find sum
				sum  = sum  + salary;
			//	System.out.println("Current sum " + sum);
				counter ++;
			}
			
		} while (str != null);// as far as line is not empty
		
		avg = sum /counter ;
		System.out.println("Avg salary is " + avg);
		
		reader.close();
		fileReader.close();
		
		
		
		
		
		
		
		

	}


}
